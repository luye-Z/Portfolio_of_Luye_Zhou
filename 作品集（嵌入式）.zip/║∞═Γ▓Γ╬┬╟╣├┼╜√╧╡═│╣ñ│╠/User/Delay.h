#ifndef __DELAY_H
#define __DELAY_H



void delay_10ms(unsigned int _10ms);

#endif
