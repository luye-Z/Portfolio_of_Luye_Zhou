#ifndef _KEY_EXIT_H_
#define _KEY_EXIT_H_

void KEY_EXTI_Init(void);
void Change_Use_Mode(void);
#endif 

