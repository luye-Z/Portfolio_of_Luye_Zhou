#ifndef __DELAY_H__
#define __DELAY_H__

void Delay1500ms(void);
void Delay200ms(void);

#endif
