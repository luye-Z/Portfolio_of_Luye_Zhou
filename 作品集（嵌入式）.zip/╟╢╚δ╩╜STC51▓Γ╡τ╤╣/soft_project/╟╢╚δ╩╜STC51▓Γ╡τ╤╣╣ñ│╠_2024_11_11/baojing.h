#ifndef __BAOJING_H__
#define __BAOJING_H__

void baojing(void);

#endif
